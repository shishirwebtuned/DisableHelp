import express from "express";
import { adminOnly, protect } from "../middleware/auth.middleware.js";
import {
  changePassword,
  forgotPassword,
  getAllUsers,
  getMe,
  getUserById,
  loginUser,
  registerUser,
  resendVerificationEmail,
  resetPassword,
  verifyEmail,
  verifyOtp,
} from "../controllers/user.controller.js";

const router = express.Router();

router.post("/login", loginUser);
router.post("/register", registerUser);
router.post("/forgot-password", forgotPassword);
router.post("/verify-otp", verifyOtp);
router.post("/reset-password", resetPassword);
router.post("/change-password", protect, changePassword);

router.get("/all", getAllUsers);
router.get("/me", protect, getMe);
router.get("/:userId", protect, getUserById);
router.post("/verify-email", verifyEmail);
router.post("/resend-verify-email", resendVerificationEmail);

export default router;
